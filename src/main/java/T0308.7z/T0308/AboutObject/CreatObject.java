package T0308.AboutObject;

/**
 * Created by vip on 2018/3/8.
 */
public class CreatObject {
    /**
     * Class 和 Instance 概念 区别
     */

    /**
     * Instance 创建过程：
     * 1.无继承：分配内存空间，初始化变量，调用构造函数
     * 2.有继承：处理静态动作，分配内存空间，变量定义为初始值，
     * 从基类->子类，处理定义出的初始化，执行构造方法
     */

    /**
     * important: 静态属性等从基类->子类进行初始化
     * 默认无参构造方法相关的特性
     */
}
