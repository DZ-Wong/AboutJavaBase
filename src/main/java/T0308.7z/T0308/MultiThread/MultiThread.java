package T0308.MultiThread;

/**
 * Created by vip on 2018/3/8.
 */
public class MultiThread {
    /**
     * 多线程在有大量IO操作阻塞的情况下，有利于提高效率
     */

    /**
     * 多线程实现和启动
     */

    /**
     * callable 和 runable 区别
     */

    /**
     * syncrhoized  reentrantLock 各自特点和比对
     */

    /**
     * 线程池
     */

    /**
     * future 异步方式获取执行结果
     */

    /**
     * concurren 包
     */

    /**
     * lock
     */
}
