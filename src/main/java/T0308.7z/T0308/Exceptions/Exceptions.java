package T0308.Exceptions;

/**
 * Created by vip on 2018/3/8.
 */
public class Exceptions {
    /**
     * 处理应该统一，避免各处散落很多异常处理逻辑；异常可控-相应要有应对方法（运维）；
     *
     */

    /**
     * 体系：
     * Throwable；
     * Exception；
     * RuntimeException；
     * Error。
     */

    /**
     * RuntimeException and Exception  区别。
     */
}
