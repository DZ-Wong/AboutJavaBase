package T0308.Static;

/**
 * Created by vip on 2018/3/8.
 */
public class Static {

    /**
     * Static用法，与其他关键字联合使用：abstract， final
     */

    /**
     * 静态属性的定义，使用，以及类加载时如何初始化
     */

    /**
     * 静态方法的define and use
     */

    /**
     * static class define and use
     */

    /**
     * static code block define and use, init step
     */
}
