package T0308.RunJava;

/**
 * Created by vip on 2018/3/8.
 */
public class AboutRun {
    /**
     * javac 编译java文件为class文件过程，命令
     */

    /**
     * java 命令的使用，带package的java类如何在命令行中启动
     */

    /**
     * java程序涉及到的各个路径（classpath， java.library .path , java运行的主目录等);
     */

    /**
     *
     */
}
