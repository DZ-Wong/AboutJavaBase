package T0308.XmlAndJson;

/**
 * Created by vip on 2018/3/8.
 */
public class XmlAndJson {
    /**
     * xml :
     *      DOM解析 ；
     *      SAX解析 ；基本原理以及各自适用场景
     */


    /**
     * json:
     *      常见Json框架的用法：
     *      Jackson、FastJson、Gson
     */
}
