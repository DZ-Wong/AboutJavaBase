package T0308.Jvm;

/**
 * Created by vip on 2018/3/8.
 */
public class Jvm {
    /**
     * JVM内存模型和结构
     */

    /**
     * GC原理，性能调优
     */

    /**
     * 调优：Thread Dump， 分析内存结构
     */

    /**
     * class 二进制字节码结构， class loader 体系， class加载过程，实例创建过程
     */

    /**
     * 方法执行过程
     */

    /**
     * Java 各版本特性
     */
}

