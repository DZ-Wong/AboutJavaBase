package T0308.Collect;

/**
 * Created by vip on 2018/3/8.
 */
public class Collection {
    /**
     * 内部实现方式 --- 应用场景
     */

    /**
     * 集合框架体系：基础Collection， Map
     */

    /**
     * 具体集合实现的内容，List， Set， Map 具体实现，内部结构， 特殊的方法，适用场景
     */

    /**
     * 工具类Collections等用法
     */
}
