package T0308.DataType;

/**
 * Created by vip on 2018/3/8.
 */
public class DataType {

    /**
     * 基本类型，对应的对象类型
     */
    public static strictfp void dataType() {
        //整形
        int inta = 1_000_000; System.out.println("sizeof int is 4 byte; min is " + Integer.MIN_VALUE + "; max is "+ Integer.MAX_VALUE);
        long longb = 1_000_000L; System.out.println("sizeof long is 8 byte; min is " + Long.MIN_VALUE+ "; max is " + Long.MAX_VALUE);
        short shortc = 3; System.out.println("sizeof short is 2 byte; min is "+ Short.MIN_VALUE + "; max is " + Short.MAX_VALUE);
        byte byted = (byte)254; System.out.println("sizeof byte is 1 byte; min is " + Byte.MIN_VALUE + "; max is " + Byte.MAX_VALUE);

        //浮点型
        float floatg = 2.0F; System.out.println("sizeof float is 4 byte; min is "+ Float.MIN_VALUE + "; max is " + Float.MAX_VALUE);
        double doubleh = 3.0D; System.out.println("sizeof Double is 8 byte; min is " + Double.MIN_VALUE + "; max is " + Double.MAX_VALUE);

        char chare = 'J'; /* UTF-16字符编码中的编码单元 */

        boolean booleanf; //不是数字类型，与整数 0 1 没有关系。

        //ps(进制表达)：十六进制：0xABC； 二进制：0b1001； 八进制(前缀为0)：011
        //不需要符号，且需要多一个bit位，可以转为无符号数
//        System.out.println(Byte.toUnsignedInt(byted));
        /*可以用十六进制表示浮点数*/double afloat = 0x1.0p-10;
//        Double.POSITIVE_INFINITY - 正无穷1.0/0.0
//        Double.NEGATIVE_INFINITY - 负无穷
//        Double.NaN - 非数值， 0.0/0.0的结果
        if (Double.isNaN(doubleh)) {/*用来判断数值是否是NaN ， 不能用  x == Double.NaN 这种方式 */}
        if (Double.isInfinite(doubleh)) {/*判断是否是正负无穷*/}
        if (Double.isFinite(doubleh)) {/*用来判断既不是无穷也不是NaN*/}
        //1/10 没有精确的二进制表示， 1/3没有精确的十进制表示，精确计算用BigDecimal 类

      //常量，final- 大写；System.out 中out是例外  final String ABC = "abc"; public static final PrintStream out;
//        final 变量可以延迟初始化
        System.out.println("3 + 4 << 5 = " + (3 + 4 << 5));

        int a = 1;
        try {
            int b = a/0; //整数有异常
        } catch (ArithmeticException ex ) {
            System.out.println(ex);
        }

        double c = 2.0D;
        double d = c/0;//浮点没有异常


    }


    public static void turn() {
        //没有信息损失，合法
//        byte -> short 、 int 、 long 、double;
//        short / char  -> int、 long 、 double;
//        int -> long 、 double;
        //合法，但有信息损失
//        int -> float;
//        long -> float, double;

        int n = 42;
        String str = Integer.toString(n);
        String str2 = Integer.toString(n, 2);

        System.out.println( str  + ";"  + str2);

        n = Integer.parseInt(str);
        n = Integer.parseInt(str2, 2);

        String str3 = Double.toString(3.14);
        double x = Double.parseDouble("3.14");



    }

    public static void defaultValue() {
//        int - 0
//        Boolean -false
//        object - null

    }
    public static final String EFG = "efg";

    /**
     * 基本类型到对象类型的转换，装箱和拆箱
     */

    /**
     * Object 类型:equals, hashcode
     */

    /**
     * String 类型的特点
     */
}
