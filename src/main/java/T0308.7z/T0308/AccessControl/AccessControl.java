package T0308.AccessControl;

/**
 * Created by vip on 2018/3/8.
 */
public class AccessControl {
    /**
     * public protected default private
     * 对于class method field的修饰作用
     */
}
